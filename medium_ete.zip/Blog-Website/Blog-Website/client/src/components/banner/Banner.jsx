
import { styled, Box, Typography } from '@mui/material';

const Image = styled(Box)`
    width: 100%;
    background: url(https://img.freepik.com/free-photo/top-view-arrangement-natural-material-stationery_23-2148898233.jpg?w=1380&t=st=1685899579~exp=1685900179~hmac=4439b542479d4e70b3192979e897a961dfe38ffcf93da4f7d4618d7d41290017.jpg) center/100%  no-repeat #000;
    height: 80vh;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    margin-top:65px;
    font-size:20px;
   text-align:right;
    
`;

const Heading = styled(Typography)`
    font-size: 50px;
    color: #FFFFFF;
    line-height: 1
`;

const SubHeading = styled(Typography)`
    font-size: 20px;
    background: #FFFFFF;
`;

const Banner = () => {
    
    return (
        <Image>
        <h1>
       <i>STAY CURIOUS</i> 
        <br></br>
-----Discover stories, thinking, and expertise <br></br>
from writers on any topic.-----
</h1>
              {/* <Heading>LET'S</Heading>
            <SubHeading>BLOG</SubHeading>   */}
        </Image>
    )
}

export default Banner;