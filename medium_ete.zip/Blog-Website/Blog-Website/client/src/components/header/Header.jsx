
import { AppBar, Toolbar, styled } from '@mui/material'; 
import { Link } from 'react-router-dom';
import HomeSharpIcon from '@mui/icons-material/HomeSharp';

import { useNavigate } from 'react-router-dom';


const Component = styled(AppBar)`
    background-color:darkcyan;
    color: black;
    font-size:19px;
    opacity:1.8;
`;

const Container = styled(Toolbar)`
    justify-content:left;
    & > a {
        justify-content:left;
        padding: 30px;
        color: black;
        text-decoration: none;
    }


    .hover-button {
        /* Button styles */
        // background-color: #FFFFFF;
        // color: #000000;
        padding: 10px 20px;
        border: none;
        cursor: pointer;
      }
      
      .hover-button:hover {
        /* Hover styles */
        background-color: #000000;
        color: #FFFFFF;
      }
      
`

const Header = () => {

    const navigate = useNavigate();

    const logout = async () => navigate('/account');
        
    return (
        <Component>
            <Container>
      
                <Link to='/' class="hover-button" ><HomeSharpIcon/><b>HOME</b></Link>
                <Link to='/about'class="hover-button"><b>ABOUT</b></Link>
                <Link to='/contact'class="hover-button"><b>CONTACT</b></Link>
                <Link to='/account'class="hover-button"><b>LOGOUT</b></Link>
            </Container>
        </Component>
        



    )
}

export default Header;