
import { Box, styled, Typography, Link } from '@mui/material';
import { GitHub, Instagram, Email } from '@mui/icons-material';

const Banner = styled(Box)`
    background-image: url(https://t4.ftcdn.net/jpg/04/75/24/07/240_F_475240772_JOhT0E0qTLFgAMBVdGiA4FKsEMIPS0r7.jpg);
    width: 100%;
    height: 70vh;
    background-position: left 0px bottom 0px;
    background-size: cover;
`;

const Wrapper = styled(Box)`
    padding: 20px;
    & > h3, & > h5 {
        margin-top: 50px;
    }
`;

const Text = styled(Typography)`
    color: #878787;
`;

const About = () => {

    return (
        <Box>
            <Banner/>
            <Wrapper>
                <Typography variant="h3">Welcome to our blogging website! </Typography>
                <Text variant="h5">We are passionate about providing a platform for individuals to express their thoughts, share their experiences, and engage with a diverse community of readers from around the world. Here's a glimpse into who we are and what we stand for:<br></br>
<br></br>
<b><u>Our Mission:</u></b><br></br>
our mission is to foster a vibrant online space where individuals can unleash their creativity, share valuable insights, and inspire others. We believe that everyone has a unique story to tell, a
<br></br>
<b><u>What We Offer:</u></b>
<br></br>

    A Platform for Expression: We provide an easy-to-use interface and intuitive tools that enable bloggers of all levels to publish their content effortlessly. Whether you're a seasoned writer or just starting your blogging journey, we strive to make the process as smooth and enjoyable as possible.

   <br></br>
<b><u>Join Our Community:</u></b><br></br>
We invite you to become part of our vibrant community of bloggers and readers. Whether you're passionate about writing, seeking inspiration, or simply love discovering captivating stories, there's a place for you here. Share your unique voice, connect with like-minded individuals, and embark on a journey of personal growth and exploration.

Thank you for being a part of our blogging website. Together, let's celebrate the power of words and create a world of endless possibilities.

                 
                </Text>
                <Text variant="h5">
                Thank you for being a part of our blogging website. Together, let's celebrate the power of words and create a world of endless possibilities.
                    <Box component="span" style={{ marginLeft: 5 }}><br></br>

                        <Link href="https://www.instagram.com/medium/?hl=en" color="inherit" target="_blank">
                            <Instagram />
                        </Link>
                    </Box>  
                     
                     
                </Text>
            </Wrapper>
        </Box>
    )
}

export default About;